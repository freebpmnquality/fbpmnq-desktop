define("ace/snippets/tsx",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="tsx"});                (function() {
                    window.require(["ace/snippets/tsx"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            