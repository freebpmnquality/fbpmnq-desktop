# fbpmnq-desktop
 Desktop tool for quality estimation of BPMN process description files.
